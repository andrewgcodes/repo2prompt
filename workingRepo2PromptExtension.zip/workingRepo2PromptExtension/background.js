// Check if running in a Chrome extension environment
if (typeof chrome !== "undefined" && chrome.action && chrome.action.onClicked) {
  chrome.action.onClicked.addListener((tab) => {
    // Check if the current tab's URL is a GitHub repository
    if (tab.url && tab.url.includes('github.com')) {
      // Create a new window to keep the popup persistent
      chrome.windows.create({
        url: chrome.runtime.getURL('popup.html'),
        type: 'popup',
        width: 400,
        height: 300
      });
    } else {
      console.log('Not a GitHub repository URL');
    }
  });
}

// Function to parse the GitHub URL and extract the repository owner and name
function parseGitHubUrl(url) {
  const path = new URL(url).pathname.split('/');
  const owner = path[1];
  const repo = path[2];
  return { owner, repo };
}

// Function to fetch the repository content using GitHub API
async function fetchRepoContent(owner, repo, path = '', token) {
  const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
  const headers = {
    'Authorization': `token ${token}`,
    'Accept': 'application/vnd.github.v3+json',
    'Origin': 'chrome-extension://jfmglpiemgnaibnhjlilhbgbbhhkhlhf'
  };
  const response = await fetch(apiUrl, { headers });
  if (!response.ok) throw new Error('GitHub API error');
  return response.json();
}
// Function to retrieve and decode the content of files
async function getFileContent(fileInfo, token) {
  if (fileInfo.download_url) {
    const headers = {
      'Authorization': `token ${token}`,
      'Accept': 'application/vnd.github.v3+json',
      'Origin': 'chrome-extension://jfmglpiemgnaibnhjlilhbgbbhhkhlhf'
    };
    const response = await fetch(fileInfo.download_url, { headers });
    if (!response.ok) throw new Error('GitHub file content fetch error');
    return response.text();
  } else {
    throw new Error('File content not available');
  }
}

// Function to build a string representation of the directory tree and collect file paths
async function buildDirectoryTree(owner, repo, path = '', token, indent = 0, fileContents = {}) {
  const items = await fetchRepoContent(owner, repo, path, token);
  let treeStr = '';
  for (const item of items) {
    if (item.path.includes('.github')) continue;
    if (item.type === 'dir') {
      treeStr += '    '.repeat(indent) + `[${item.name}/]\n`;
      treeStr += await buildDirectoryTree(owner, repo, item.path, token, indent + 1, fileContents);
    } else {
      treeStr += '    '.repeat(indent) + `${item.name}\n`;
      if (item.name.match(/\.(py|ipynb|html|css|js|jsx|rst|md)$/)) {
        fileContents[item.path] = await getFileContent(item, token);
      }
    }
  }
  return treeStr;
}

// Function to generate the text file with the repository contents
async function generateTextFile(owner, repo, token) {
  try {
    let formattedContent = '';
    let fileContents = {};
    let directoryTree = await buildDirectoryTree(owner, repo, '', token, 0, fileContents);

    formattedContent += `Directory Structure:\n${directoryTree}\n`;

    for (const [path, content] of Object.entries(fileContents)) {
      formattedContent += `\n${path}:\n\`\`\`\n${content}\n\`\`\`\n`;
    }

    return formattedContent;
  } catch (error) {
    console.error(error);
    throw error; // Rethrow the error to be caught by the calling function
  }
}

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.url && request.token) {
    const { owner, repo } = parseGitHubUrl(request.url);
    generateTextFile(owner, repo, request.token)
      .then(formattedContent => {
        sendResponse({ formattedContent });
      })
      .catch(error => {
        sendResponse({ error: error.message });
      });
    return true; // Required to use sendResponse asynchronously
  }
});

// Export the necessary functions to be used in test scripts
if (typeof module !== "undefined" && module.exports) {
  module.exports = { generateTextFile, parseGitHubUrl };
}
