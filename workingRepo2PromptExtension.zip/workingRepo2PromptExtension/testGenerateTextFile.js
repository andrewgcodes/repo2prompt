// Import the generateTextFile and parseGitHubUrl functions from background.js
const { generateTextFile, parseGitHubUrl } = require('./background.js');

// Placeholder values for testing
const testUrl = 'https://github.com/nomic-ai/nomic/tree/main'; // Replace with a valid GitHub repository URL for real testing
const testToken = ''// Replace with an actual token for real testing

// Function to simulate the message passing from the popup script to the background script
async function testGenerateTextFile() {
  try {
    // Extract the owner and repo from the URL
    const { owner, repo } = parseGitHubUrl(testUrl);

    // Call the generateTextFile function
    const formattedContent = await generateTextFile(owner, repo, testToken);

    // Output the result to the console
    console.log('Formatted Content:', formattedContent);
  } catch (error) {
    console.error('Error generating text file:', error);
  }
}

// Run the test
testGenerateTextFile();
