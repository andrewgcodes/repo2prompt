document.addEventListener('DOMContentLoaded', function() {
  var generateButton = document.getElementById('generate');
  var repoUrlInput = document.getElementById('repoUrl');
  var accessTokenInput = document.getElementById('accessToken');
  var statusDisplay = document.getElementById('status');

  // Function to update status messages
  function updateStatus(message) {
    statusDisplay.textContent = message;
    statusDisplay.style.display = 'block';
  }

  // Function to hide status messages
  function hideStatus() {
    statusDisplay.style.display = 'none';
  }

  // Automatically fill in the GitHub repository URL if the popup is opened on a GitHub page
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    var currentTabUrl = tabs[0].url;
    if (currentTabUrl.includes('github.com')) {
      repoUrlInput.value = currentTabUrl;
    }
  });

  generateButton.addEventListener('click', function() {
    var repoUrl = repoUrlInput.value;
    var accessToken = accessTokenInput.value;

    if (repoUrl && accessToken) {
      updateStatus('Fetching repository contents...');
      chrome.runtime.sendMessage({url: repoUrl, token: accessToken}, function(response) {
        if (chrome.runtime.lastError) {
          updateStatus('Error: ' + chrome.runtime.lastError.message);
        } else if (response.error) {
          updateStatus('Error: ' + response.error);
        } else {
          updateStatus('Creating download link...');
          // Create a Blob from the formatted content
          const blob = new Blob([response.formattedContent], { type: 'text/plain' });
          const url = URL.createObjectURL(blob);

          // Create a link and set the URL as the href
          const link = document.createElement('a');
          link.href = url;
          link.download = 'repository-content.txt';

          // Append the link to the body, click it, and remove it
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);

          // Revoke the blob URL
          URL.revokeObjectURL(url);

          updateStatus('Repository content downloaded successfully.');
        }
      });
    } else {
      updateStatus('Repository URL and Access Token are required.');
    }
  }, false);

  // Hide status when user starts editing the fields
  repoUrlInput.addEventListener('input', hideStatus);
  accessTokenInput.addEventListener('input', hideStatus);
}, false);