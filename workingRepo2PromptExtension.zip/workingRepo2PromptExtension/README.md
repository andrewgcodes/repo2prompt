
# Repo2Prompt Extension

## Introduction
The Repo2Prompt Extension is a Chrome browser extension that allows users to generate a text file with the contents of a GitHub repository. It requires a GitHub repository URL and a personal access token to fetch the repository contents.

## Installation
To install the Repo2Prompt Extension:
1. Download the extension package.
2. Open the Chrome browser and navigate to `chrome://extensions/`.
3. Enable 'Developer mode' at the top right corner.
4. Click on 'Load unpacked' and select the extension package directory.
5. The Repo2Prompt Extension should now be added to your browser.

## Usage
To use the Repo2Prompt Extension:
1. Click on the extension icon in the Chrome toolbar.
2. Enter the GitHub repository URL in the 'GitHub Repository URL' field.
3. Enter your GitHub personal access token in the 'Access Token' field.
4. Click the 'Generate Text File' button.
5. The extension will fetch the repository contents and download a text file named `[repo]-formatted-prompt.txt`.

## Troubleshooting
If you encounter any issues while using the Repo2Prompt Extension, please ensure that:
- The GitHub repository URL is correct and accessible.
- The personal access token has the correct permissions and is valid.
- You have a stable internet connection.

For further assistance, please contact support.
